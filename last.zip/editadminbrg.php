<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<br>
<?php
$id = $_GET['id'];
$brg= mysqli_query($koneksi, "select * from brg where id='$id'");
$row = mysqli_fetch_array($brg);
?>
<form method="post" action="editbrg.php">
<input type="hidden" value="<?php echo $row['id'];?>" name="id">
<table>
<tr><td>Nama :</td><td><input type="text" value="<?php echo $row['nama'];?>" name="nama"></td></tr>
<tr><td>Harga :</td><td><input type="number" value="<?php echo $row['harga'];?>" name="harga"></td></tr>
<tr><td>Jumlah:</td><td><input type="number" value="<?php echo $row['jumlah'];?>" name="jumlah"></td></tr>
<tr><td>Userjual:</td><td><input type="text" value="<?php echo $row['userjual'];?>" name="userjual"></td></tr>

<tr><td colspan="2"><button type="submit" value="simpan">SIMPAN PERUBAHAN</button>
<a href="admin.php">Back</a></td></tr>
</table>
</form>
</b>
</center>
</body>
</html>