<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<?php
$user=$_POST['user'];
$pass=$_POST['pass'];
$hp=$_POST['hp'];
$query="INSERT INTO jual VALUES('$user','$pass','$hp'); ";
if(mysqli_query($koneksi,$query))
{
 include 'inputbarang.php';
}
else
{
 include 'gagal_signup.php';
}
?>
</body>
</html>