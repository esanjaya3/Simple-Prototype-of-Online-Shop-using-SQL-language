<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php 
include 'koneksi.php';
?>
</head>
<body>
<p>
<center><img src="logo3.png" width="300"> <br><br>
<b>
<table>
<tr><td>INPUT Barang</td></tr> 
<form method="post" action="inputlagi.php">

<tr><td>Nama:</td><td><input type="text" name="nama"></td><td></td></tr>
<tr><td>Harga:</td><td><input type="number" name="harga"></td></tr>
<tr><td>Jumlah:</td><td><input type="number" name="jumlah"></td></tr>
<tr><td>User:</td><td><input type="text" name="user" value="<?php echo "$user";?>"></td></tr>
<tr><td>

<tr><td><button type="submit" value="simpan">JUAL</button></td></tr>
</form> 
</table>
</b>

<a href='main.php'>Kembali</a>
</center>
</p>
</body>
</html>