<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<br>
<?php
$id = $_GET['id'];
$query="DELETE from brg where id='$id'";
mysqli_query($koneksi, $query);
include 'updateadminbrg.php';
?>
</b>
</center>
</body>
</html>