<?php
$server = "localhost";
$user = "root";
$pass= "";

$con=mysqli_connect($server,$user,$pass);
if (!$con) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
echo "Koneksi Berhasil";
echo "<br>";
$database= "CREATE DATABASE proyek2";
if (mysqli_query($con,$database)) {
    echo "Database berhasil";
} else {
    echo "Database gagal: " . mysqli_error($con);
}
mysqli_close($con);
echo "<br>";

$server = "localhost";
$user = "root";
$pass= "";
$db="proyek2";

$con=mysqli_connect($server,$user,$pass,$db);
if (!$con) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}
echo "Koneksi database berhasil";

echo "<br>";

$tabel = "CREATE TABLE beli (
user VARCHAR(50),
pass VARCHAR(50),
hp INT(15),
PRIMARY KEY (user)
)";
if (mysqli_query($con,$tabel))
{
    echo "Tabel beli Berhasil";
}
else 
{
    echo "Tabel Error: " . mysqli_error($con);
}
echo "<br>";

$tabel = "CREATE TABLE jual(
user VARCHAR(50),
pass VARCHAR(50),
hp INT(15),
PRIMARY KEY (user)
)";

if (mysqli_query($con,$tabel))
{
    echo "Tabel jual Berhasil";
}
else 
{
    echo "Tabel Error: " . mysqli_error($con);
}
echo "<br>";

$tabel = "CREATE TABLE pesan(
tgl TIMESTAMP(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
userbeli VARCHAR(50),
userjual VARCHAR(50),
namabrg VARCHAR(50),
jumlah INT(10),
alamat VARCHAR(50),
PRIMARY KEY (tgl)
)";

if (mysqli_query($con,$tabel))
{
    echo "Tabel pesan Berhasil";
}
else 
{
    echo "Tabel Error: " . mysqli_error($con);
}
echo "<br>";


$tabel = "CREATE TABLE brg(
id INT(11) AUTO_INCREMENT,
nama VARCHAR(50),
harga INT(6),
jumlah INT(6),
userjual VARCHAR(50),
PRIMARY KEY(id)
)";

if (mysqli_query($con,$tabel))
{
    echo "Tabel brg Berhasil";
}
else 
{
    echo "Tabel Error: " . mysqli_error($con);
}
echo "<br>";

?>