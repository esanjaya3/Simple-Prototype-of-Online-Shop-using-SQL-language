<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center><img src="logo3.png" width="300"> <br><br>
<?php
$nama=$_POST['nama'];
$jumlah=$_POST['jumlah'];
$alamat=$_POST['alamat'];
$userj=$_POST['userj'];
$user=$_POST['user'];
$query="INSERT INTO pesan(userbeli,userjual,namabrg,jumlah,alamat) VALUES('$user','$userj','$nama','$jumlah','$alamat');";
mysqli_query($koneksi,$query);
$query1="UPDATE brg INNER JOIN pesan ON brg.userjual=pesan.userjual AND brg.nama=pesan.namabrg SET brg.jumlah=brg.jumlah-pesan.jumlah WHERE pesan.userbeli='$user';";
mysqli_query($koneksi,$query1);
?>
<b>
<table border="1">
<tr>Daftar Barang</tr>
<tr><th>Nama Barang</th><th>Harga</th><th>Jumlah</th><th>User Penjual</th></tr>
<?php
$brg = mysqli_query($koneksi, "SELECT * from brg");
foreach ($brg as $row) {
echo "<tr>
<td>" . $row['nama'] . "</td>
<td>" . $row['harga'] . "</td>
<td>" . $row['jumlah'] . "</td>
<td>" . $row['userjual'] . "</td>
</tr>";
}
?>
</table>
<br>

<table>
<tr><td>Pesan Barang</td></tr> 
<form method="post" action="pesanlagi.php">

<tr><td>Nama Barang:</td><td><input type="text" name="nama"></td><td></td></tr>
<tr><td>Jumlah:</td><td><input type="number" name="jumlah"></td></tr>
<tr><td>Alamat:</td><td><input type="text" name="alamat"></td></tr>
<tr><td>User Penjual:</td><td><input type="text" name="userj"></td></tr>
<tr><td>User :</td><td><input type="text" name="user" value="<?php echo "$user";?>"></td></tr>
<tr><td>

<tr><td><button type="submit" value="simpan">BELI</button></td></tr>
</form> 
</table>
</b>
<a href='main.php'>Kembali</a>

</center>
</body>
</html>