<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<body>
<table border="1">
<tr>Daftar Pesanan</tr>
<tr><th>Tanggal</th><th>User Pembeli</th><th>User Penjual</th><th>Nama Barang</th><th>Jumlah</th><th>Alamat</th><th>Edit</th><th>Delete</th></tr>
<?php
$psn = mysqli_query($koneksi, "SELECT * from pesan");
foreach ($psn as $row) {
echo "<tr>
<td>" . $row['tgl'] . "</td>
<td>" . $row['userbeli'] . "</td>
<td>" . $row['userjual'] . "</td>
<td>" . $row['namabrg'] . "</td>
<td>" . $row['jumlah'] . "</td>
<td>" . $row['alamat'] . "</td>
<td><a href='editadminpesan.php?tgl=$row[tgl]'>Edit</a></td>
<td><a href='deletepesan.php?tgl=$row[tgl]'>Delete</a></td>
</tr>";
}
?>
</table>
<br><a href="admin.php">Back</a>
</body>
</html>