<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<?php
$pass=$_POST['pass'];
$user=$_POST['user'];
$query="SELECT pass FROM beli WHERE user='$user';";
$a=mysqli_query($koneksi,$query);
$row=mysqli_fetch_array($a, MYSQLI_NUM);
switch($pass)
{
case "admin":
	include 'admin.php';
	break;
default:
	if ($pass=$row[0])
	{
	include 'pesan.php';
	}
	else
	{
	include 'gagal_loginb.php';
	}
}
?>
</body>
</html>