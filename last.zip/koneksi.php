<?php
$host = "localhost";
$use = "root";
$password = "";
$database = "proyek2";
$koneksi = mysqli_connect($host, $use, $password, $database);
if( !$koneksi ){
die("Database error :" . mysqli_connect_error());
}
?>