<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<?php
if(isset($_POST['simpan']))
{
$tabel = $_POST['tabel'];
}

switch($tabel){
	case "beli":
	include 'updateadminbeli.php';
	break;
	case "jual":
	include 'updateadminjual.php';
	break;
	case "brg":
	include 'updateadminbrg.php';
		break;
	case "pesan":
	include 'updateadminpesan.php';
		break;
	default:
	break;
}

?>
</b>
</center>
</body>
</html>