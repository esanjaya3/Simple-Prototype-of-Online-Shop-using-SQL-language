<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<?php
$user=$_POST['user'];
$pass=$_POST['pass'];
$hp=$_POST['hp'];
$query="UPDATE jual SET user='$user',pass='$pass',hp='$hp'; ";
mysqli_query($koneksi, $query);
?>
<center><b><h1>Welcome Admin !!!</h1>
<?php
include 'updateadminjual.php';
?>

</body>
</html>