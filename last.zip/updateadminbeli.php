<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<body>
<table border="1">
<tr>Daftar Pembeli</tr>
<tr><th>User Pembeli</th><th>Password</th><th>No HP</th><th>Edit</th><th>Delete</th></tr>
<?php
$beli = mysqli_query($koneksi, "SELECT * from beli");
foreach ($beli as $row) {
echo "<tr>
<td>" . $row['user'] . "</td>
<td>" . $row['pass'] . "</td>
<td>" . $row['hp'] . "</td>
<td><a href='editadminbeli.php?user=$row[user]'>Edit</a></td>
<td><a href='deletebeli.php?user=$row[user]'>Delete</a></td>
</tr>";
}
?>
</table><br>
<a href="admin.php">Back</a>
</body>
</html>