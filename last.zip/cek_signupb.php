<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<?php
$user=$_POST['user'];
$pass=$_POST['pass'];
$hp=$_POST['hp'];
$query="INSERT INTO beli VALUES('$user','$pass','$hp'); ";
if(mysqli_query($koneksi,$query))
{
 include 'pesan.php';
}
else
{
 include 'gagal_signupb.php';
}
?>
</body>
</html>