<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<br>
<?php
$user = $_GET['user'];
$beli = mysqli_query($koneksi, "select * from beli where user='$user'");
$row = mysqli_fetch_array($beli);
?>
<form method="post" action="editbeli.php">
<input type="hidden" value="<?php echo $row['user'];?>" name="user">
<table>
<tr><td>User :</td><td><input type="text" value="<?php echo $row['user'];?>" name="user"></td></tr>
<tr><td>Pass :</td><td><input type="password" value="<?php echo $row['pass'];?>" name="pass"></td></tr>
<tr><td>No.HP:</td><td><input type="number" value="<?php echo $row['hp'];?>" name="hp"></td></tr>

<tr><td colspan="2"><button type="submit" value="simpan">SIMPAN PERUBAHAN</button>
<a href="admin.php">Back</a></td></tr>
</table>
</form>
</b>
</center>
</body>
</html>