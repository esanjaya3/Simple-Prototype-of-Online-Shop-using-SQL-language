<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<br>
<?php
$tgl= $_GET['tgl'];
$pesan= mysqli_query($koneksi, "select * from pesan where tgl='$tgl'");
$row = mysqli_fetch_array($pesan);
?>
<form method="post" action="editpesan.php">
<input type="hidden" value="<?php echo $row['tgl'];?>" name="tgl">
<table>
<tr><td>Tanggal :</td><td><input type="text" value="<?php echo $row['tgl'];?>" name="tgl"></td></tr>
<tr><td>Userbeli :</td><td><input type="text" value="<?php echo $row['userbeli'];?>" name="userbeli"></td></tr>
<tr><td>Userjual :</td><td><input type="text" value="<?php echo $row['userjual'];?>" name="userjual"></td></tr>
<tr><td>Nama Barang:</td><td><input type="text" value="<?php echo $row['namabrg'];?>" name="namabrg"></td></tr>
<tr><td>Jumlah:</td><td><input type="number" value="<?php echo $row['jumlah'];?>" name="jumlah"></td></tr>
<tr><td>Alamat:</td><td><input type="text" value="<?php echo $row['alamat'];?>" name="alamat"></td></tr>

<tr><td colspan="2"><button type="submit" value="simpan">SIMPAN PERUBAHAN</button>
<a href="admin.php">Back</a></td></tr>
</table>
</form>
</b>
</center>
</body>
</html>