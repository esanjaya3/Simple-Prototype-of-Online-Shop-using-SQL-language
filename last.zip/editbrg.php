<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<?php
$nama=$_POST['nama'];
$harga=$_POST['harga'];
$jumlah=$_POST['jumlah'];
$user=$_POST['userjual'];
$query="UPDATE brg SET nama='$nama',harga='$harga',jumlah='$jumlah',userjual='$user'; ";
mysqli_query($koneksi, $query);
?>
<center><b><h1>Welcome Admin !!!</h1>
<?php
include 'updateadminbrg.php';
?>

</body>
</html>