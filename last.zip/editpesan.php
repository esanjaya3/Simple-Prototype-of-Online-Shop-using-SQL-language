<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<?php
$tgl=$_POST['tgl'];
$nama=$_POST['namabrg'];
$jumlah=$_POST['jumlah'];
$alamat=$_POST['alamat'];
$userj=$_POST['userjual'];
$user=$_POST['userbeli'];
$query="UPDATE brg SET tgl='$tgl',namabrg'$nama',jumlah='$jumlah',alamat='$alamat',userbeli='$user',userjual='$userj'; ";
mysqli_query($koneksi, $query);
?>
<center><b><h1>Welcome Admin !!!</h1>
<?php
include 'updateadminpesan.php';
?>

</body>
</html>