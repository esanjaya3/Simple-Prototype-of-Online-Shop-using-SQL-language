<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<p>
<center><img src="logo3.png" width="300"> <br><br>
<b>
<table>
<tr><td>User name sudah ada coba lain</td></tr> 
<tr><td>SIGN UP pembeli</td></tr> 
<form method="post" action="cek_signupb.php">

<tr><td>User:</td><td><input type="text" name="user"></td><td>@gmail.com</td></tr>
<tr><td>Pass:</td><td><input type="password" name="pass"></td></tr>
<tr><td>No.HP:</td><td><input type="number" name="hp"></td></tr>
<tr><td>

<tr><td><button type="submit" value="simpan">SIGN UP</button></td></tr>
</form> 
</table>
</b>
<a href='main.php'>Kembali</a>
</center>
</p>
</body>
</html>