<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<?php
$pass=$_POST['pass'];
$user=$_POST['user'];
$query="SELECT pass FROM jual WHERE user='$user';";
$a=mysqli_query($koneksi,$query);
$row=mysqli_fetch_array($a, MYSQLI_NUM);
switch($pass)
{
case "admin":
	include 'admin.php';
	break;
default:
	if ($pass=$row[0])
	{

	include 'inputbarang.php';
	}
	else
	{
	include 'gagal_login.php';
	}
}


?>
</body>
</html>