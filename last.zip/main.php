<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<h2><center><img src="logo3.png" width="300"></center>
</h2>
<center>
<h1>
.Welcome.
<br><br>
<a href="pembeli.php"><img src="pembeli.png" width="200"></a>
<a href="penjual.php"><img src="penjual.png" width="200"></a>
<p>Pembeli &nbsp Penjual</p>
</h1>

</center>


</body>
</html>