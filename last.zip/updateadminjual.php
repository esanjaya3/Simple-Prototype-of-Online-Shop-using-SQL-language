<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<body>
<table border="1">
<tr>Daftar Penjual</tr>
<tr><th>User Penjual</th><th>Password</th><th>No HP</th><th>Edit</th><th>Delete</th></tr>
<?php
$jual = mysqli_query($koneksi, "SELECT * from jual");
foreach ($jual as $row) {
echo "<tr>
<td>" . $row['user'] . "</td>
<td>" . $row['pass'] . "</td>
<td>" . $row['hp'] . "</td>
<td><a href='editadminjual.php?user=$row[user]'>Edit</a></td>
<td><a href='deletejual.php?user=$row[user]'>Delete</a></td>
</tr>";
}
?>
</table><br><a href="admin.php">Back</a>
</body>
</html>