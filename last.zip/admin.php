<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<br>
<table>
<form method="post" action="updateadmin.php">
<tr><td>Pilih Tabel:</td>
<td><select name="tabel">
<option value="beli">Pembeli</option>
<option value="jual">Penjual</option>
<option value="brg">Barang</option>
<option value="pesan">Pesanan</option>
</select></td>
<td><button type="submit" name="simpan">SELECT</button></td></tr>
</form> 
</table>
<br>
<a href='main.php'>Main Page</a>
</b>
</center>
</body>
</html>