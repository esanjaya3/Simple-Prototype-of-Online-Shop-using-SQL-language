<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<p>
<center><img src="logo3.png" width="300"> <br><br>
<b>
<table>
<tr><td>LOG IN penjual</td></tr>
<form method="post" action="cek_login.php">

<tr><td>User:</td><td><input type="text" name="user"></td><td>@gmail.com</td></tr>
<tr><td>Pass:</td><td><input type="password" name="pass"></td></tr>

<tr><td><button type="submit" value="simpan">LOG IN</button></td></tr>
</form> 
</b>
</table>
<table>
<tr><td><b>SIGN UP penjual</td></tr> 
<form method="post" action="cek_signup.php">

<tr><td>User:</td><td><input type="text" name="user"></td><td>@gmail.com</td></tr>
<tr><td>Pass:</td><td><input type="password" name="pass"></td></tr>
<tr><td>No.HP:</td><td><input type="number" name="hp"></td></tr>
<tr><td>

<tr><td><button type="submit" value="simpan">SIGN UP</button></td></tr>
</form> 
</b>
</table>
<a href='main.php'>Kembali</a>
</center>
</p>
</body>
</html>

