<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<body>
<table border="1">
<tr>Daftar Barang</tr>
<tr><th>Nama Barang</th><th>Harga</th><th>Jumlah</th><th>User Penjual</th><th>Edit</th><th>Delete</th></tr>
<?php
$brg = mysqli_query($koneksi, "SELECT * from brg");
foreach ($brg as $row) {
echo "<tr>
<td>" . $row['nama'] . "</td>
<td>" . $row['harga'] . "</td>
<td>" . $row['jumlah'] . "</td>
<td>" . $row['userjual'] . "</td>
<td><a href='editadminbrg.php?id=$row[id]'>Edit</a></td>
<td><a href='deletebrg.php?id=$row[id]'>Delete</a></td>
</tr>";
}
?>

</table>
<br><a href="admin.php">Back</a>
</body>
</html>