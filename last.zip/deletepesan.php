<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<br>
<?php
$tgl = $_GET['tgl'];
$query="DELETE from pesan where tgl='$tgl'";
mysqli_query($koneksi, $query);
include 'updateadminpesan.php';
?>
</b>
</center>
</body>
</html>