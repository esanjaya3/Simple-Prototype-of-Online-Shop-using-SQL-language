<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php include 'koneksi.php';?>
</head>
<body>
<center>
<b><h1>Welcome Admin !!!</h1><br>
<br>
<?php
$user = $_GET['user'];
$query="DELETE from beli where user='$user'";
mysqli_query($koneksi, $query);
include 'updateadminbeli.php';
?>
</b>
</center>
</body>
</html>