<!DOCTYPE html>
<html>
<link rel="stylesheet" href="style.css">
<head>
<?php 
include 'koneksi.php';
?>
</head>
<body>
<p>
<center><img src="logo3.png" width="300"> <br><br>
<b>
<table border="1">
<tr>Daftar Barang</tr>
<tr><th>Nama Barang</th><th>Harga</th><th>Jumlah</th><th>User Penjual</th></tr>
<?php
$brg = mysqli_query($koneksi, "SELECT * from brg");
foreach ($brg as $row) 
{
echo "<tr>
<td>" . $row['nama'] . "</td>
<td>" . $row['harga'] . "</td>
<td>" . $row['jumlah'] . "</td>
<td>" . $row['userjual'] . "</td>
</tr>";
}
?>
</table>
<br>
<table>
<tr><td>Pesan Barang</td></tr> 
<form method="post" action="pesanlagi.php">
<tr><td>Nama Barang:</td><td><input type="text" name="nama"></td><td></td></tr>
<tr><td>Jumlah:</td><td><input type="number" name="jumlah"></td></tr>
<tr><td>Alamat:</td><td><input type="text" name="alamat"></td></tr>
<tr><td>User Penjual:</td><td><input type="text" name="userj"></td></tr>
<tr><td>User :</td><td><input type="text" name="user" value="<?php echo "$user";?>"></td></tr>
<tr><td>
<tr><td><button type="submit" value="simpan">BELI</button></td></tr>
</form> 
</table>
</b>
<a href='main.php'>Kembali</a>
</center>
</p>

</body>
</html>